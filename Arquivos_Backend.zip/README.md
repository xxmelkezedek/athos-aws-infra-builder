# AWS Infrastructure Builder

Uma ferramenta visual para **projetar, validar e revisar arquiteturas AWS** — que vai além de desenhar ícones e realmente *modela* infraestrutura.

Você arrasta serviços para um canvas, conecta-os, e a ferramenta:

- **Modela** cada recurso com dezenas de propriedades reais (tipo de instância, Multi-AZ, criptografia, placement, etc.), com campos condicionais que aparecem conforme o contexto.
- **Valida** contra boas práticas com um motor que lê essas propriedades e aponta problemas no formato **Crítico / Impacto / Correção / Referência** (ex.: "RDS em subnet pública → exposição da camada de dados → mover para privada → Well-Architected").
- **Recomenda** o que falta, olhando o padrão de conexões (desenhe CloudFront→ALB→EC2→RDS e ele sugere WAF, ACM, Route 53, Auto Scaling, Secrets Manager, CloudWatch, Backup, Systems Manager).
- **Pontua** a arquitetura pelos 6 pilares do **AWS Well-Architected Framework**.
- **Estima o custo** mensal aproximado lendo a configuração real de cada nó.
- **Gera** Terraform, AWS CLI e roteiros de laboratório a partir do diagrama.
- **Importa** JSON, CloudFormation e **Terraform** — reconstruindo o diagrama a partir de código real. O importador de Terraform faz o caminho inverso do gerador, fechando o ciclo diagrama ↔ código.
- **Conversa** com um **Arquiteto de IA** que enxerga o *seu* diagrama e responde perguntas sobre ele.

---

## Arquitetura do projeto

O projeto tem duas partes, propositalmente desacopladas:

### 1. Front-end — `AWS_Infra_Builder.html` (um único arquivo)

Todo o núcleo (canvas, modelagem, validação, recomendações, custo, geradores, importadores, autosave) roda **100% no navegador, sem servidor**. Você pode abrir o HTML direto e usar tudo. O estado é salvo automaticamente no `localStorage`.

### 2. Back-end — `backend/` (Node.js + Express) — **opcional**

Existe por **um único motivo**: dar ao front acesso a um modelo de IA sem expor a chave da API no navegador. O front nunca vê a chave; ele manda um resumo do diagrama + a pergunta, e o backend injeta a chave e chama o modelo.

> **Por que um backend, e por que só isto?**
> Uma chave de API não pode viver em JavaScript de front — qualquer pessoa a leria no DevTools. Esconder um segredo assim é exatamente para o que um backend serve. Deliberadamente **não** há credenciais AWS nem integração "ao vivo" com a conta da AWS: isso exigiria guardar segredos sensíveis do usuário e traria risco real. O backend aqui é o **mínimo defensável** — um proxy para a IA, nada mais.

**Degradação elegante:** se o backend não estiver rodando, o app inteiro continua funcionando; apenas o painel de IA mostra instruções para ligá-lo.

---

## Como rodar

### Front-end
Abra `AWS_Infra_Builder.html` no navegador. Só isso. Todas as funcionalidades exceto o Arquiteto de IA funcionam offline.

### Back-end (para habilitar o Arquiteto de IA)

Pré-requisito: Node.js 18+.

```bash
cd backend
npm install
cp .env.example .env      # e edite o .env com a sua ANTHROPIC_API_KEY
npm start
```

O servidor sobe em `http://localhost:8787`. Volte ao app, abra **🧠 Arquiteto IA** e o indicador ficará verde. Pergunte coisas como:

- "O que está faltando nesta arquitetura?"
- "Quais são os riscos de segurança?"
- "Por que o custo está nesse valor?"
- "O que um revisor sênior criticaria aqui?"

A IA responde olhando o diagrama real: os serviços, as conexões, os problemas que o motor de validação já detectou e a estimativa de custo.

---

## Decisões de engenharia que valem destacar

- **Reversibilidade diagrama ↔ código.** O app gera Terraform *e* importa Terraform. O importador é um parser HCL pragmático (reconhece os `resource "aws_..."` comuns, extrai config, infere conexões por referências como `${aws_vpc.main.id}`) — não um parser completo, mas o suficiente para ler infraestrutura real.
- **Regras determinísticas + IA, lado a lado.** As recomendações e validações são um motor de regras rápido, previsível e offline. A IA é uma camada por cima para nuance e linguagem natural. Cada uma no seu lugar.
- **Modelagem retrocompatível.** Adicionar propriedades ricas a um recurso não quebra os geradores, templates ou o import/export — as chaves originais são preservadas.
- **Segurança por omissão.** A chave da IA nunca chega ao cliente; erros do backend nunca vazam detalhes internos; o input é limitado em tamanho.

---

## Limitações conhecidas (honestidade > marketing)

- A estimativa de custo é **ordem de grandeza**, não uma cotação — preços aproximados, datados, sem transferência de dados/requisições/free tier.
- O importador de Terraform cobre os recursos `aws_*` mais comuns; o que foge disso é ignorado com aviso.
- O autosave é local ao navegador (não sincroniza entre dispositivos — para isso, use o export/import JSON).
- O backend é para uso local/desenvolvimento; para produção, fixe o CORS e adicione rate limiting.

---

## Stack

Front: HTML/CSS/JavaScript puro (sem framework, sem build).
Back: Node.js, Express, SDK da Anthropic.
