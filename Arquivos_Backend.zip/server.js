// ============================================================================
//  AWS Infrastructure Builder — AI Architect Backend
// ----------------------------------------------------------------------------
//  Um proxy mínimo e honesto. Sua única razão de existir: guardar a chave da
//  API de IA fora do navegador. O front NUNCA vê a chave — ele manda o resumo
//  do diagrama + a pergunta, este servidor injeta a chave e chama o modelo.
//
//  Por que backend? Uma chave de API não pode viver em JS de front (qualquer
//  um leria no DevTools). Esconder um segredo assim é exatamente o tipo de
//  coisa para a qual um backend serve. Nada de credenciais AWS aqui — só a
//  chave da IA. É o servidor mínimo defensável.
// ============================================================================

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import Anthropic from '@anthropic-ai/sdk';

dotenv.config();

const PORT = process.env.PORT || 8787;
const AI_MODEL = process.env.AI_MODEL || 'claude-sonnet-4-6';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*';

if (!process.env.ANTHROPIC_API_KEY) {
  console.error('\n[ERRO] ANTHROPIC_API_KEY não definida. Copie .env.example para .env e preencha a chave.\n');
  process.exit(1);
}

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const app = express();
app.use(cors({ origin: ALLOWED_ORIGIN }));
app.use(express.json({ limit: '256kb' })); // diagramas são pequenos; limite protege contra abuso

// ---- Health check: o front usa isto para saber se o servidor está no ar ----
app.get('/health', (_req, res) => {
  res.json({ ok: true, model: AI_MODEL });
});

// ---- O sistema que transforma a IA num revisor de arquitetura ----------------
const SYSTEM_PROMPT = `Você é um arquiteto de soluções AWS sênior revisando o diagrama de infraestrutura de um colega dentro de uma ferramenta visual.

Você recebe, a cada pergunta, um RESUMO estruturado do diagrama atual: os serviços e suas configurações (apenas o que difere do padrão), as conexões entre eles, os problemas que o motor de validação da ferramenta já detectou (com severidade, impacto e correção), uma estimativa de custo mensal fixo, e as recomendações que o motor determinístico já gerou.

Seu papel:
- Responder à pergunta do usuário olhando ESPECIFICAMENTE o diagrama dele, não dando respostas genéricas.
- Referenciar os serviços e conexões reais pelo nome quando relevante.
- Quando o motor de validação já apontou um problema, você pode aprofundar o "porquê" e o "como corrigir", não apenas repetir.
- Priorizar: segurança e confiabilidade primeiro, depois custo e performance.
- Ser direto e conciso. Use markdown leve: **negrito** para pontos-chave, ## para seções curtas, listas com - quando fizer sentido. Nada de tabelas.
- Alinhar-se ao AWS Well-Architected Framework quando fizer sentido, citando o pilar.
- Se a arquitetura estiver vazia ou a pergunta não tiver relação com ela, diga isso com franqueza e ofereça ajuda relevante.
- Nunca invente serviços que não estão no diagrama como se estivessem lá. Se recomendar algo novo, deixe claro que é uma adição sugerida.

Responda em português do Brasil. Seja o revisor que o usuário gostaria de ter ao lado: honesto, específico e construtivo.`;

// ---- Endpoint principal ------------------------------------------------------
app.post('/api/architect', async (req, res) => {
  try {
    const { question, context, history } = req.body || {};

    if (!question || typeof question !== 'string') {
      return res.status(400).json({ error: 'Pergunta ausente ou inválida.' });
    }

    // Monta a mensagem do usuário: contexto do diagrama + a pergunta.
    const contextBlock = context && !context.empty
      ? `Aqui está o resumo do diagrama atual (JSON):\n\n${JSON.stringify(context, null, 2)}`
      : `O diagrama está vazio no momento.`;

    // Histórico curto da conversa (já limitado pelo front), para dar continuidade.
    const priorMessages = Array.isArray(history)
      ? history
          .filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
          .slice(-8)
          .map(m => ({ role: m.role, content: m.content }))
      : [];

    // A última pergunta vem acompanhada do contexto do diagrama.
    const messages = [
      ...priorMessages.slice(0, -1), // histórico anterior (sem a última, que remontamos)
      { role: 'user', content: `${contextBlock}\n\n---\n\nPergunta: ${question}` },
    ];

    const response = await anthropic.messages.create({
      model: AI_MODEL,
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages,
    });

    const answer = response.content
      .filter(b => b.type === 'text')
      .map(b => b.text)
      .join('\n')
      .trim();

    res.json({ answer: answer || '(sem resposta)' });
  } catch (err) {
    // Nunca vaza a chave nem detalhes internos sensíveis para o cliente.
    console.error('[api/architect] erro:', err?.message || err);
    const status = err?.status && Number.isInteger(err.status) ? err.status : 500;
    res.status(status).json({
      error: status === 401
        ? 'Chave de API inválida no servidor.'
        : status === 429
          ? 'Limite de uso atingido. Tente novamente em instantes.'
          : 'Falha ao consultar o modelo de IA.',
    });
  }
});

app.listen(PORT, () => {
  console.log(`\n🧠 AI Architect backend no ar em http://localhost:${PORT}`);
  console.log(`   Modelo: ${AI_MODEL}`);
  console.log(`   CORS: ${ALLOWED_ORIGIN}`);
  console.log(`   Endpoints: GET /health · POST /api/architect\n`);
});
